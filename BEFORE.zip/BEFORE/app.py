from flask import Flask, render_template, request, redirect, session
import sqlite3
import hashlib

app = Flask(__name__)
app.secret_key = "weak_secret"

# نربطه بقاعدة البيانات اللي في الجذر
DB_PATH = "../app.db"

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # علشان القوالب تقدر تستخدم user.username
    return conn

@app.route("/")
def index():
    return redirect("/login")

# ------------------------
# Register (BEFORE)
# ------------------------
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        email = request.form.get("email", "")

        # ❌ Weak password hashing (MD5)
        password_hash = hashlib.md5(password.encode()).hexdigest()

        db = get_db()
        # ❌ SQL Injection vulnerability
        db.execute(
            f"INSERT INTO users (username, password_hash, role, email_encrypted) "
            f"VALUES ('{username}', '{password_hash}', 'user', '{email}')"
        )
        db.commit()
        return redirect("/login")

    return render_template("register.html")

# ------------------------
# Login (BEFORE)
# ------------------------
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        # ❌ Weak password hashing (MD5)
        password_hash = hashlib.md5(password.encode()).hexdigest()

        db = get_db()
        # ❌ SQL Injection vulnerability
        query = f"SELECT * FROM users WHERE username = '{username}' AND password_hash = '{password_hash}'"
        user = db.execute(query).fetchone()

        if user:
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["role"] = user["role"]
            return redirect("/dashboard")

    return render_template("login.html")

# ------------------------
# Dashboard
# ------------------------
@app.route("/dashboard")
def dashboard():
    if "user_id" not in session:
        return redirect("/login")

    db = get_db()
    user = db.execute(
        "SELECT * FROM users WHERE id = ?",
        (session["user_id"],)
    ).fetchone()

    return render_template("dashboard.html", user=user)

# ------------------------
# Comments (BEFORE - SQLi + XSS)
# ------------------------
@app.route("/comments", methods=["GET", "POST"])
def comments():
    db = get_db()

    if request.method == "POST":
        content = request.form["content"]

        if "user_id" not in session:
            return redirect("/login")

        user_id = session["user_id"]

        # ❌ intentionally vulnerable to SQLi & XSS — BEFORE version
        query = "INSERT INTO comments (user_id, content) VALUES (" + str(user_id) + ", '" + content + "')"
        db.execute(query)
        db.commit()

    comments = db.execute(
        """
        SELECT comments.content, users.username, comments.created_at
        FROM comments
        JOIN users ON comments.user_id = users.id
        ORDER BY comments.id DESC
        """
    ).fetchall()

    return render_template("comments.html", comments=comments)

# ------------------------
# Admin (BEFORE - No RBAC)
# ------------------------
@app.route("/admin")
def admin():
    db = get_db()
    users = db.execute("SELECT * FROM users").fetchall()
    return render_template("admin.html", users=users)

# ------------------------
# Logout
# ------------------------
@app.route("/logout")
def logout():
    session.clear()
    return redirect("/login")

# ------------------------
# Run
# ------------------------
if __name__ == "__main__":
    app.run(debug=True)
