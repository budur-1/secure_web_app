import os
from cryptography.fernet import Fernet

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

# In real deployment these should come from environment variables
SECRET_KEY = os.environ.get("FLASK_SECRET_KEY") or os.urandom(32)

# Symmetric key for encrypting sensitive fields (e.g., email)
FERNET_KEY = os.environ.get("FERNET_KEY")
if not FERNET_KEY:
    # In production: generate once, store outside code, e.g. in .env / secret manager
    FERNET_KEY = Fernet.generate_key().decode()

DATABASE_PATH = os.path.join(BASE_DIR, "app.db")

# Security flags for cookies
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_SAMESITE = "Lax"
# When served over HTTPS, also force:
SESSION_COOKIE_SECURE = False  # set True in production behind HTTPS
