from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
import bcrypt
from cryptography.fernet import Fernet
from functools import wraps

# ✅ Load secure configuration
from config import SECRET_KEY, FERNET_KEY, DATABASE_PATH

app = Flask(__name__)
app.secret_key = SECRET_KEY

# ✅ Secure session cookie settings
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=True  # ✅ Correct since HTTPS is enabled
)

DB_PATH = DB_PATH = "../app.db"
fernet = Fernet(FERNET_KEY.encode())

# -----------------------------
# Database Connection
# -----------------------------
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

# -----------------------------
# Password Security (bcrypt)
# -----------------------------
def hash_password(password):
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()

def check_password(password, hashed):
    return bcrypt.checkpw(password.encode(), hashed.encode())

# -----------------------------
# Encryption (Fernet)
# -----------------------------
def encrypt(text):
    return fernet.encrypt(text.encode()) if text else None

def decrypt(text):
    return fernet.decrypt(text).decode() if text else ""

# -----------------------------
# Role-Based Access Control
# -----------------------------
def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "user_id" not in session or session.get("role") != "admin":
            flash("Unauthorized access", "danger")
            return redirect("/dashboard")
        return f(*args, **kwargs)
    return wrapper

# -----------------------------
# Routes
# -----------------------------
@app.route("/")
def index():
    return redirect("/login")

# -----------------------------
# Register (SQLi + bcrypt + encryption)
# -----------------------------
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        email = request.form.get("email", "")

        password_hash = hash_password(password)
        email_encrypted = encrypt(email)

        db = get_db()
        db.execute(
            "INSERT INTO users (username, password_hash, role, email_encrypted) VALUES (?, ?, ?, ?)",
            (username, password_hash, "user", email_encrypted)
        )
        db.commit()
        return redirect("/login")

    return render_template("register.html")

# -----------------------------
# Login (SQLi + bcrypt)
# -----------------------------
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        db = get_db()
        user = db.execute(
            "SELECT * FROM users WHERE username = ?",
            (username,)
        ).fetchone()

        if user and check_password(password, user["password_hash"]):
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["role"] = user["role"]
            return redirect("/dashboard")

        flash("Invalid username or password", "danger")

    return render_template("login.html")

# -----------------------------
# Dashboard
# -----------------------------
@app.route("/dashboard")
def dashboard():
    if "user_id" not in session:
        return redirect("/login")

    db = get_db()
    user = db.execute(
        "SELECT * FROM users WHERE id = ?",
        (session["user_id"],)
    ).fetchone()

    email = decrypt(user["email_encrypted"])

    return render_template("dashboard.html", user=user, email=email)

# -----------------------------
# Comments (SQLi + XSS protected)
# -----------------------------
@app.route("/comments", methods=["GET", "POST"])
def comments():
    if "user_id" not in session:
        return redirect("/login")

    db = get_db()

    if request.method == "POST":
        content = request.form["content"]
        db.execute(
            "INSERT INTO comments (user_id, content) VALUES (?, ?)",
            (session["user_id"], content)
        )
        db.commit()

    comments = db.execute(
        """
        SELECT comments.content, users.username, comments.created_at
        FROM comments
        JOIN users ON comments.user_id = users.id
        ORDER BY comments.id DESC
        """
    ).fetchall()

    return render_template("comments.html", comments=comments)

# -----------------------------
# Admin (RBAC protected)
# -----------------------------
@app.route("/admin")
@admin_required
def admin():
    db = get_db()
    users = db.execute(
        "SELECT id, username, role FROM users"
    ).fetchall()

    return render_template("admin.html", users=users)

# -----------------------------
# Logout
# -----------------------------
@app.route("/logout")
def logout():
    session.clear()
    return redirect("/login")

# -----------------------------
# HTTPS Enabled
# -----------------------------
if __name__ == "__main__":
    app.run(ssl_context="adhoc", debug=True)
